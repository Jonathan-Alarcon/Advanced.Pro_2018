#include <cstdlib>
#include <iostream>
#include "stdlib.h"

using namespace std; /* cin,cout,endl */
#define ARCHIVO_TXT c:/Users/Sala5/archivo.txt //Respaldo de datos
int main(int argc, char *argv[])
{
    
    cout<<"HOLA MUNDO C++ Curso Programaci\\'n Avanzada"<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
